Bonjour,

Ci-joint le projet Architecture des ordinateurs sur le produit matriciel (exo12).

Je suis en MIMP , je rattrape le TP avec l'accord de Mr S.Meftali.
Je vous ai envoyé un mail decrivant la situation.

Cordialement,
Djebien Tarik.
